#ifndef INFORME_H_INCLUDED
#define INFORME_H_INCLUDED
typedef struct
{
int idCliente;
int idPublicacion;
    //------------
}eInforme;

void informe_cantidadPorCliente(ePublicacion* arrayPublicacion, int tamPubl, eCliente* arrayClientes, int tamClientes);

#endif // INFORME_H_INCLUDED
