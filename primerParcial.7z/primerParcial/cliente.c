#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "cliente.h"
#include "utn.h"

/** \brief
 * \param arrayCliente eCliente*
 * \param limite int
 * \return int
 *
 */
int cliente_init(eCliente* arrayCliente,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && arrayCliente != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            arrayCliente[i].isEmpty=1;
            arrayCliente[i].CantPublicaciones = 0;
        }
    }
    return retorno;
}

int cliente_mostrarDebug(eCliente* arrayCliente,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && arrayCliente != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            printf("[DEBUG] - %d - %s - %d\n",arrayCliente[i].idCliente, arrayCliente[i].nombre, arrayCliente[i].isEmpty);
        }
    }
    return retorno;
}

int cliente_mostrar(eCliente* arrayCliente,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && arrayCliente != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!arrayCliente[i].isEmpty)
                printf("[RELEASE] - %d - %s - %d\n",arrayCliente[i].idCliente, arrayCliente[i].nombre, arrayCliente[i].isEmpty);
        }
    }
    return retorno;
}

int cliente_alta(eCliente* arrayCliente,int limite)
{
    int retorno = -1;
    int i;
    char buffer[50];
    if(limite > 0 && arrayCliente != NULL)
    {
        i = cliente_buscarLugarLibre(arrayCliente,limite);
        if(i >= 0)
        {
            if(!getValidString("\nNombre? ","\nEso no es un nombre","El maximo es 40",buffer,40,2))
            {
                retorno = 0;
                strcpy(arrayCliente[i].nombre,buffer);
                //------------------------------
                //------------------------------
                arrayCliente[i].idCliente = cliente_proximoId();
                arrayCliente[i].isEmpty = 0;
            }
            if(!getValidString("\nApellido? ","\nEso no es un apellido","El maximo es 50",buffer,50,2)){
              strcpy(arrayCliente[i].apellido,buffer);
            }
            if(getStringNumeros("ingrese el cuit",buffer)){

                strcpy(arrayCliente[i].cuit,buffer);
                printf("Alta Correcta ID: %d \n", arrayCliente[i].idCliente);
            }
            else
            {
                retorno = -3;
            }
        }
        else
        {
            retorno = -2;
        }

    }
    return retorno;
}


int cliente_baja(eCliente* arrayCliente,int limite, int id)
{
    int retorno = -1;
    int i;
    if(limite > 0 && arrayCliente != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!arrayCliente[i].isEmpty && arrayCliente[i].idCliente==id)
            {
                arrayCliente[i].isEmpty = 1;
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}




int cliente_modificacion(eCliente* arrayCliente,int limite, int id)
{
    int retorno = -1;
    int i;
    char buffer[50];
    if(limite > 0 && arrayCliente != NULL)
    {
        retorno = -2;
        for(i=0;i<limite;i++)
        {
            if(!arrayCliente[i].isEmpty && arrayCliente[i].idCliente==id)
            {
                if(!getValidString("\nNombre? ","\nEso no es un nombre","El maximo es 40",buffer,40,2))
                {
                    retorno = 0;
                    strcpy(arrayCliente[i].nombre,buffer);
                    //------------------------------
                    //------------------------------
                }
                  if(!getValidString("\nApellido? ","\nEso no es un nombre","El maximo es 40",buffer,40,2))
                {
                    strcpy(arrayCliente[i].apellido,buffer);
                    //------------------------------
                    //------------------------------
                }
                if(getStringNumeros("ingrese el cuit",buffer)){

                strcpy(arrayCliente[i].cuit,buffer);

                }
                else
                {
                    retorno = -3;
                }
                retorno = 0;
                break;
            }
        }
    }
    return retorno;
}

int cliente_ordenar(eCliente* arrayCliente,int limite, int orden)
{
    int retorno = -1;
    int i;
    int flagSwap;
    eCliente auxiliarEstructura;

    if(limite > 0 && arrayCliente != NULL)
    {
        do
        {
            flagSwap = 0;
            for(i=0;i<limite-1;i++)
            {
                if(!arrayCliente[i].isEmpty && !arrayCliente[i+1].isEmpty)
                {
                    if((strcmp(arrayCliente[i].nombre,arrayCliente[i+1].nombre) > 0 && orden) || (strcmp(arrayCliente[i].nombre,arrayCliente[i+1].nombre) < 0 && !orden)) //******
                    {
                        auxiliarEstructura = arrayCliente[i];
                        arrayCliente[i] = arrayCliente[i+1];
                        arrayCliente[i+1] = auxiliarEstructura;
                        flagSwap = 1;
                    }
                }
            }
        }while(flagSwap);
    }
    return retorno;
}

int cliente_buscarLugarLibre(eCliente* arrayCliente,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && arrayCliente != NULL)
    {
        for(i=0;i<limite;i++)
        {
            if(arrayCliente[i].isEmpty==1)
            {
                retorno = i;
                break;
            }
        }
    }
    return retorno;
}


int cliente_proximoId()
{
    static int proximoId = -1;
    proximoId++;
    return proximoId;
}
int cliente_altaForzada(eCliente* arrayCliente,int tam,char* nombre,char* apellido, char* cuit)
{
    int retorno = -1;
    int i;

    if(tam > 0 && arrayCliente != NULL)
    {
        i = cliente_buscarLugarLibre(arrayCliente,tam);
        if(i >= 0)
        {
            retorno = 0;
            strcpy(arrayCliente[i].nombre,nombre);
            strcpy(arrayCliente[i].apellido,apellido);
            strcpy(arrayCliente[i].cuit,cuit);
            //------------------------------
            //------------------------------
            arrayCliente[i].idCliente = cliente_proximoId();
            arrayCliente[i].isEmpty = 0;
        }
        retorno = 0;
    }
    return retorno;
}

int cliente_mostrarConCantidad(eCliente* arrayCliente,int limite)
{
    int retorno = -1;
    int i;
    if(limite > 0 && arrayCliente != NULL)
    {
        retorno = 0;
        for(i=0;i<limite;i++)
        {
            if(!arrayCliente[i].isEmpty)
                printf("[RELEASE] - %d - %s - cantidad %d\n",arrayCliente[i].idCliente, arrayCliente[i].nombre,arrayCliente[i].CantPublicaciones);
        }
    }
    return retorno;
}
