
#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "publicacion.h"
#include "cliente.h"
#include "utn.h"

void informe_cantidadPorCliente(ePublicacion* arrayPublicacion, int tamPubl, eCliente* arrayClientes, int tamClientes){
int i, j;
for(i=0;i< tamPubl;i++){
    for(j=0;j<tamPubl; j++){
        if(arrayPublicacion[i].idCliente == arrayPublicacion[j].idCliente){
            arrayClientes[i].CantPublicaciones ++;
        }
    }

}
}
