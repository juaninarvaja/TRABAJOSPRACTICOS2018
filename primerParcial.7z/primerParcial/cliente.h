#ifndef CLIENTE_H_INCLUDED
#define CLIENTE_H_INCLUDED
typedef struct
{
    char nombre[50];
    char apellido[50];
    char cuit[20];
    //------------
    int idCliente;
    int isEmpty;
    int CantPublicaciones;
}eCliente;
#endif // CLIENTE_H_INCLUDED


int cliente_init(eCliente* arrayCliente,int limite);
int cliente_mostrar(eCliente* arrayCliente,int limite);
int cliente_mostrarDebug(eCliente* arrayCliente,int limite);
int cliente_alta(eCliente* arrayCliente,int limite);
int cliente_baja(eCliente* arrayCliente,int limite, int id);
int cliente_modificacion(eCliente* arrayCliente,int limite, int id);
int cliente_ordenar(eCliente* arrayCliente,int limite, int orden);
int cliente_buscarLugarLibre(eCliente* arrayCliente,int limite);
int cliente_proximoId();
int cliente_altaForzada(eCliente* arrayCliente,int tam,char* nombre,char* apellido, char* cuit);
int cliente_mostrarConCantidad(eCliente* arrayCliente,int limite);
