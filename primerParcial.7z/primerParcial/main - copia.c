#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <string.h>
#include "publicacion.h"
#include "cliente.h"
#include "utn.h"
#include "informe.h"
#define TAM_CLI 100
#define TAM_PUB 100

int main()
{
    eCliente arrayClientes[TAM_CLI];
    ePublicacion arrayPublicacion[TAM_PUB];
    int i;
    int menu;
    int auxiliarId;
    cliente_init(arrayClientes,TAM_CLI);
    publicacion_init(arrayPublicacion,TAM_PUB);

     publicacion_altaForzada(arrayPublicacion,TAM_PUB,"Vendo perros",0,2);
    publicacion_altaForzada(arrayPublicacion,TAM_PUB,"Vendo Gatos",0,3);
    publicacion_altaForzada(arrayPublicacion,TAM_PUB,"Vendo tele",1,30);
    publicacion_altaForzada(arrayPublicacion,TAM_PUB,"Vendo Celu",1,30);
    publicacion_altaForzada(arrayPublicacion,TAM_PUB,"Vendo pintura",2,20);

    cliente_altaForzada(arrayClientes,TAM_CLI,"Marcos","acu�a","20124615");
    cliente_altaForzada(arrayClientes,TAM_CLI,"Jose","Pereyra","20184615");
    cliente_altaForzada(arrayClientes,TAM_CLI,"Matias","Gomez","20158615");






    do
    {
        getValidInt("1.Alta Clientes\n2.Modificar Clientes\n3.Baja Cliente\n4.Publicar aviso\n5.Pausar Publicacion\n6.Renaudar Publicacion\n7.Imprime Clientes\n8.Imprime Publicaciones\n9.Informa Clientes\n10.Informar publicaciones \n 11.Salir\n","\nNo valida\n",&menu,1,12,1);
        switch(menu)
        {
            case 1:
                cliente_alta(arrayClientes,TAM_CLI);
                break;
            case 2:
                getValidInt("ID?","\nNumero valida\n",&auxiliarId,0,200,2);
                cliente_modificacion(arrayClientes,TAM_CLI,auxiliarId);
                break;
            case 3:
                cliente_mostrar(arrayClientes,TAM_CLI);
                printf("ingrese la id a borrar");
                scanf("%d",&i);
              if(publicacion_buscaIdCliente(arrayPublicacion,TAM_PUB,i)){
                cliente_baja(arrayClientes,TAM_CLI,i);

                }
                break;
            case 4:
                publicacion_alta(arrayPublicacion,TAM_PUB);

                break;
            case 5:
                publicacion_mostrar(arrayPublicacion,TAM_PUB);
                printf("ingrese la id a pausar");
                scanf("%d",&i);
                publicacion_pausarPublicacion(arrayPublicacion,TAM_PUB,i);
                break;
            case 6:
                publicacion_mostrarPausadas(arrayPublicacion,TAM_PUB);
                printf("ingrese la id a activar");
                scanf("%d",&i);
                publicacion_ActivarPublicacion(arrayPublicacion,TAM_PUB,i);

                break;
            case 7:
                 informe_cantidadPorCliente(arrayPublicacion,TAM_PUB,arrayClientes,TAM_CLI);
                 cliente_mostrarConCantidad(arrayClientes,TAM_CLI);
                break;
            case 8:

                break;
            case 9:

                break;
            case 10:

                break;
        }

    }while(menu != 9);

    return 0;
}

